/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   StringToDecimal.h
 * Author: pierluigi
 *
 * Created on 20 dicembre 2017, 15.45
 */

#ifndef STRINGTODECIMAL_H
#define STRINGTODECIMAL_H

int stringToDecimal(char letter) {
    int decimal = static_cast<int> (letter);

    if (decimal <= 90 && decimal >= 65)
        return decimal - 65;

    if (decimal <= 122 && decimal >= 97)
        return decimal - 97;

    if (decimal == -88 || decimal == -87)
        return 4; //è

    if (decimal == -96)
        return 0; //à

    if (decimal == -78)
        return 14; //ò

    if (decimal == -71)
        return 20; //ù

    if (decimal == -84)
        return 8; //ì

    if (decimal == 45)
        return 45;

    return -1;
}

#endif /* STRINGTODECIMAL_H */

