/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: pierluigi
 *
 * Created on 20 dicembre 2017, 15.12
 */

#include <sys/time.h>
#ifdef _OPENMP
#include <omp.h> // for OpenMP library functions
#endif
#include <cstdlib>
#include <iostream>
#include <vector>
#include <fstream>

#include "StringToDecimal.h"

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

    int tid;

    vector<vector<vector<int> > > triGrams;
    vector<vector<int> > biGrams;
    vector<int> letters;
    for (int i = 0; i < 26; i++) {
        letters.push_back(0);
    }
    for (int i = 0; i < 26; i++) {
        biGrams.push_back(letters);
    }
    for (int i = 0; i < 26; i++) {
        triGrams.push_back(biGrams);
    }

    vector<string> text;
    string line;
    ifstream myfile("file/Storia dei musulmani di Sicilia.txt");
    if (myfile.is_open()) {
        while (getline(myfile, line)) {
            text.push_back(line);
        }
        myfile.close();
    } else cout << "Unable to open file";

    for (int i = 0; i < text.size(); i++) {
        if (text[i].length() == 0) {
            text.erase(text.begin() + i);
            i--;
        }
    }

    int numberLineOfSecondLetter;
    int secondLetterIndex;
    int numberLineOfThirdLetter;
    int thirdLetterIndex;
    
#ifdef _OPENMP
    double start_time = omp_get_wtime()*1000000;
#endif
#pragma omp parallel for private(numberLineOfSecondLetter,secondLetterIndex, numberLineOfThirdLetter, thirdLetterIndex) shared(biGrams)
    for (int i = 0; i < text.size(); i++) {
        for (int j = 0; j < text[i].length(); j++) {
            if (stringToDecimal(text[i][j]) != -1 && stringToDecimal(text[i][j]) != 45) {
                secondLetterIndex = j + 1;
                numberLineOfSecondLetter = i;
                if (secondLetterIndex != text[numberLineOfSecondLetter].length()) {
                    if (secondLetterIndex == text[numberLineOfSecondLetter].length() - 1 && stringToDecimal(text[numberLineOfSecondLetter][secondLetterIndex]) == 45) {
                        numberLineOfSecondLetter++;
                        secondLetterIndex = 0;
                        if (numberLineOfSecondLetter != text.size()) {
                            if (stringToDecimal(text[numberLineOfSecondLetter][secondLetterIndex]) != -1 && stringToDecimal(text[numberLineOfSecondLetter][secondLetterIndex]) != 45) {
                                numberLineOfThirdLetter = numberLineOfSecondLetter;
                                thirdLetterIndex = secondLetterIndex + 1;
                                if (thirdLetterIndex != text[numberLineOfSecondLetter].length()) {
                                    if (stringToDecimal(text[numberLineOfThirdLetter][thirdLetterIndex]) != -1 && stringToDecimal(text[numberLineOfThirdLetter][thirdLetterIndex]) != 45) {
#pragma omp atomic
                                        triGrams[stringToDecimal(text[i][j])][stringToDecimal(text[numberLineOfSecondLetter][secondLetterIndex])][stringToDecimal(text[numberLineOfThirdLetter][thirdLetterIndex])]++;
                                    }
                                }
                            }
                        }
                    } else {
                        if (stringToDecimal(text[numberLineOfSecondLetter][secondLetterIndex]) != -1 && stringToDecimal(text[numberLineOfSecondLetter][secondLetterIndex]) != 45) {
                            numberLineOfThirdLetter = numberLineOfSecondLetter;
                            thirdLetterIndex = secondLetterIndex + 1;
                            if (thirdLetterIndex != text[numberLineOfSecondLetter].length()) {
                                if(thirdLetterIndex ==text[numberLineOfSecondLetter].length() - 1 && stringToDecimal(text[numberLineOfThirdLetter][thirdLetterIndex]) == 45){
                                    numberLineOfThirdLetter++;
                                    thirdLetterIndex=0;
                                    if(numberLineOfThirdLetter != text.size()){
                                        if(stringToDecimal(text[numberLineOfThirdLetter][thirdLetterIndex]) != -1 && stringToDecimal(text[numberLineOfThirdLetter][thirdLetterIndex]) != 45){
#pragma omp atomic
                                            triGrams[stringToDecimal(text[i][j])][stringToDecimal(text[numberLineOfSecondLetter][secondLetterIndex])][stringToDecimal(text[numberLineOfThirdLetter][thirdLetterIndex])]++;
                                        }
                                    }
                                }
                                else{
                                    if(stringToDecimal(text[numberLineOfThirdLetter][thirdLetterIndex]) != -1 && stringToDecimal(text[numberLineOfThirdLetter][thirdLetterIndex]) != 45){
#pragma omp atomic
                                       triGrams[stringToDecimal(text[i][j])][stringToDecimal(text[numberLineOfSecondLetter][secondLetterIndex])][stringToDecimal(text[numberLineOfThirdLetter][thirdLetterIndex])]++; 
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    //gettimeofday(&end, NULL);

#ifdef _OPENMP
    double time = (omp_get_wtime()*1000000) - start_time;
    printf("time : %f\n\n", time);
#endif

    return 0;
}
