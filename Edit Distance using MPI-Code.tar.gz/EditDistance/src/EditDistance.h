/*
 * EditDistance.h
 *
 *  Created on: 25/gen/2018
 *      Author: pierluigi
 */

#ifndef EDITDISTANCE_H_
#define EDITDISTANCE_H_

#include <vector>
#include "stringToDecimal.h"

int editDistance(std::string X,std::string Y){

	int m=X.length();
	int n=Y.length();

	std::vector<int> row;
	std::vector<std::vector<int> > EDMatrix;
	for(int i=0; i<=n; i++){
		row.push_back(0);
	}
	for(int i=0; i<=m; i++){
		EDMatrix.push_back(row);
	}

	for(int i=0; i<=m; i++){
		EDMatrix[i][0]=i;
	}
	for(int j=0; j<=n; j++){
		EDMatrix[0][j]=j;
	}

	for(int i=1; i<=m; i++){
		for(int j=1; j<=n; j++){
			if(stringToDecimal(X[i-1]) == stringToDecimal(Y[j-1])){
				EDMatrix[i][j]=EDMatrix[i-1][j-1];
			}
			if(stringToDecimal(X[i-1]) != stringToDecimal(Y[j-1])){
				EDMatrix[i][j]=EDMatrix[i-1][j-1]+1;
			}
			/*if(i >= 2 && j >= 2 && stringToDecimal(X[i-1]) == stringToDecimal(Y[j-2]) && stringToDecimal(X[i-2]) == stringToDecimal(Y[j-1]) && EDMatrix[i-2][j-2]+1 < EDMatrix[i][j]){
				EDMatrix[i][j]=EDMatrix[i-2][j-2]+1;
			}*/
			if(EDMatrix[i-1][j] + 1 < EDMatrix[i][j]){
				EDMatrix[i][j]=EDMatrix[i-1][j]+1;
			}
			if(EDMatrix[i][j-1] + 1 < EDMatrix[i][j]){
				EDMatrix[i][j]=EDMatrix[i][j-1]+1;
			}
		}
	}

	return EDMatrix[m][n];

}


#endif /* EDITDISTANCE_H_ */
