/*
 ============================================================================
 Name        : EditDistance.c
 Author      : Pierluigi
 Version     :
 Copyright   : Your copyright notice
 Description : EditDistance
 ============================================================================
 */

#include <fstream>
#include <iostream>
#include <sstream>
#include <cstring>
#include <algorithm>
#include <map>

#include "mpi.h"
#include "EditDistance.h"

using namespace std;

int main(int argc, char *argv[]) {

	int my_rank;
	int processes;
	char wordFound[30];
	int tolerance = 1;
	int editdistance;

	int response = -1;
	int finalIteration = 0;
	int numberText = -1;

	int firstIndex;
	int secondIndex;
	int thirdIndex;

	map<string, map<int, map<string, vector<int> > > > wordsFound;
	map<int, string> nameText;
	vector<string> inputWords;
	vector<vector<string> > texts;

	inputWords.push_back("giunta");
	inputWords.push_back("banana");
	inputWords.push_back("selva");
	inputWords.push_back("fatto");
	inputWords.push_back("signore");

	for (int i = 0; i < inputWords.size(); i++) {
		if (inputWords[i].length() == 0) {
			inputWords.erase(inputWords.begin() + i);
			i--;
		}
	}

	for (int i = 0; i < inputWords.size(); i++) {
		for (int j = 0; j < inputWords[i].length(); j++) {
			if (static_cast<bool>(std::ispunct(inputWords[i][j]))) {
				std::replace(inputWords[i].begin(), inputWords[i].end(),
						static_cast<char>(inputWords[i][j]), ' ');
			}
		}

		for (int j = 0; j < inputWords[i].length(); j++) {
			if (static_cast<int>(inputWords[i][j]) == -62
					|| static_cast<int>(inputWords[i][j]) == -69) {
				int decimal = static_cast<int>(inputWords[i][j]);
				std::replace(inputWords[i].begin(), inputWords[i].end(),
						static_cast<char>(inputWords[i][j]), ' ');
				if (decimal == -62) {
					std::replace(inputWords[i].begin(), inputWords[i].end(),
							static_cast<char>(inputWords[i][j + 1]), ' ');
				}
			}
		}
	}

	vector<string> text1;
	string line;
	ifstream myfile1("src/file/I rossi e i neri.txt");
	if (myfile1.is_open()) {
		while (getline(myfile1, line)) {
			text1.push_back(line);
		}
		myfile1.close();
	} else
		cout << "Unable to open file";

	for (int i = 0; i < text1.size(); i++) {
		if (text1[i].length() == 0) {
			text1.erase(text1.begin() + i);
			i--;
		}
	}
	texts.push_back(text1);
	nameText[0] = "I rossi e i neri";

	vector<string> text2;
	ifstream myfile2("src/file/Il bacio della contessa Savina.txt");
	if (myfile2.is_open()) {
		while (getline(myfile2, line)) {
			text2.push_back(line);
		}
		myfile2.close();
	} else
		cout << "Unable to open file";

	for (int i = 0; i < text2.size(); i++) {
		if (text2[i].length() == 0) {
			text2.erase(text2.begin() + i);
			i--;
		}
	}
	texts.push_back(text2);
	nameText[1] = "Il bacio della contessa Savina";

	vector<string> text3;
	ifstream myfile3("src/file/I Barbarò: le lacrime del prossimo.txt");
	if (myfile3.is_open()) {
		while (getline(myfile3, line)) {
			text3.push_back(line);
		}
		myfile3.close();
	} else
		cout << "Unable to open file";

	for (int i = 0; i < text3.size(); i++) {
		if (text3[i].length() == 0) {
			text3.erase(text3.begin() + i);
			i--;
		}
	}
	texts.push_back(text3);
	nameText[2] = "I Barbarò: le lacrime del prossimo";

	vector<string> text4;
	ifstream myfile4("src/file/La vita in Palermo.txt");
	if (myfile4.is_open()) {
		while (getline(myfile4, line)) {
			text4.push_back(line);
		}
		myfile4.close();
	} else
		cout << "Unable to open file";

	for (int i = 0; i < text4.size(); i++) {
		if (text4[i].length() == 0) {
			text4.erase(text4.begin() + i);
			i--;
		}
	}
	texts.push_back(text4);
	nameText[3] = "La vita in Palermo";

	vector<string> text5;
	ifstream myfile5(
			"src/file/Storia delle repubbliche italiane dei secoli di mezzo.txt");
	if (myfile5.is_open()) {
		while (getline(myfile5, line)) {
			text5.push_back(line);
		}
		myfile5.close();
	} else
		cout << "Unable to open file";

	for (int i = 0; i < text5.size(); i++) {
		if (text5[i].length() == 0) {
			text5.erase(text5.begin() + i);
			i--;
		}
	}
	texts.push_back(text5);
	nameText[4] = "Storia delle repubbliche italiane dei secoli di mezzo";

	MPI_Init(&argc, &argv); // start MPI library
	MPI_Comm_rank(MPI_COMM_WORLD, &my_rank); // Find out process rank
	MPI_Comm_size(MPI_COMM_WORLD, &processes); // Find out number of processes
	if (my_rank == 0) {

		int iMax = inputWords.size() - 1;

		int jMax = -1;
		for (int i = 0; i < texts.size(); i++) {
			for (int j = 0; j < texts[i].size(); j++) {
				if (texts[i][j].length() != 0) {
					jMax++;
				}
			}
		}

		double starttime, endtime;
		double time = 0;

		int process = 1;
		int iteration = -1;
		for (int i = 0; i < inputWords.size(); i++) {
			for (int j = 0; j < texts.size(); j++) {
				for (int k = 0; k < texts[j].size(); k++) {
					starttime = clock();
					iteration++;
					numberText = j;
					if ((processes - 1) > (iMax * (jMax + 1) + jMax)) {
						finalIteration = 1;
					} else {
						if ((iteration)
								> (iMax * (jMax + 1) + jMax - processes + 1)) {
							finalIteration = 1;
						}
					}
					endtime = clock();
					time += (endtime - starttime);
					if (process < processes) {
						MPI_Send(&finalIteration, 1,
						MPI_INT, process, 0,
						MPI_COMM_WORLD);
						MPI_Send(&i, 1,
						MPI_INT, process, 0,
						MPI_COMM_WORLD);
						MPI_Send(&j, 1,
						MPI_INT, process, 0,
						MPI_COMM_WORLD);
						MPI_Send(&k, 1,
						MPI_INT, process, 0,
						MPI_COMM_WORLD);
						MPI_Send(&numberText, 1,
						MPI_INT, process, 0,
						MPI_COMM_WORLD);
						starttime = clock();
						process++;
						endtime = clock();
						time += (endtime - starttime);
					} else {
						starttime = clock();
						process = 1;
						endtime = clock();
						time += (endtime - starttime);
						for (int source = 1; source < processes; source++) {
							starttime = clock();
							MPI_Status status;
							MPI_Probe(MPI_ANY_SOURCE, MPI_ANY_TAG,
							MPI_COMM_WORLD, &status);
							MPI_Recv(&response, 1, MPI_INT, status.MPI_SOURCE,
							MPI_ANY_TAG,
							MPI_COMM_WORLD,
							MPI_STATUS_IGNORE);
							endtime = clock();
							time += (endtime - starttime);
							while (response != 2) {
								if (response == 1) {
									MPI_Recv(&firstIndex, 1, MPI_INT,
											status.MPI_SOURCE,
											MPI_ANY_TAG, MPI_COMM_WORLD,
											MPI_STATUS_IGNORE);
									MPI_Recv(wordFound, 30, MPI_CHAR,
											status.MPI_SOURCE,
											MPI_ANY_TAG, MPI_COMM_WORLD,
											MPI_STATUS_IGNORE);
									starttime = clock();
									std::string inputWordReceived(inputWords[firstIndex]);
									std::string wordFoundReceived(wordFound);
									memset(wordFound, 0, sizeof(wordFound));
									endtime = clock();
									time += (endtime - starttime);
									MPI_Recv(&editdistance, 1, MPI_INT,
											status.MPI_SOURCE,
											MPI_ANY_TAG, MPI_COMM_WORLD,
											MPI_STATUS_IGNORE);
									MPI_Recv(&numberText, 1, MPI_INT,
											status.MPI_SOURCE,
											MPI_ANY_TAG, MPI_COMM_WORLD,
											MPI_STATUS_IGNORE);
									starttime = clock();
									if (wordsFound[inputWordReceived][numberText].find(
											wordFoundReceived)
											== wordsFound[inputWordReceived][numberText].end()) {
										wordsFound[inputWordReceived][numberText][wordFoundReceived].push_back(
												editdistance);
										wordsFound[inputWordReceived][numberText][wordFoundReceived].push_back(
												1);
									} else
										wordsFound[inputWordReceived][numberText][wordFoundReceived][1]++;
									endtime = clock();
									time += (endtime - starttime);
								}
								starttime = clock();
								MPI_Recv(&response, 1, MPI_INT,
										status.MPI_SOURCE,
										MPI_ANY_TAG,
										MPI_COMM_WORLD,
										MPI_STATUS_IGNORE);
								endtime = clock();
								time += (endtime - starttime);
							}
						}
						MPI_Send(&finalIteration, 1,
						MPI_INT, process, 0,
						MPI_COMM_WORLD);
						MPI_Send(&i, 1,
						MPI_INT, process, 0,
						MPI_COMM_WORLD);
						MPI_Send(&j, 1,
						MPI_INT, process, 0,
						MPI_COMM_WORLD);
						MPI_Send(&k, 1,
						MPI_INT, process, 0,
						MPI_COMM_WORLD);
						MPI_Send(&numberText, 1,
						MPI_INT, process, 0,
						MPI_COMM_WORLD);
						starttime = clock();
						process++;
						endtime = clock();
						time += (endtime - starttime);
					}
				}
			}
		}
		for (int source = 1; source < process; source++) {
			starttime = clock();
			MPI_Status status;
			MPI_Probe(MPI_ANY_SOURCE, MPI_ANY_TAG,
			MPI_COMM_WORLD, &status);
			MPI_Recv(&response, 1, MPI_INT, status.MPI_SOURCE,
			MPI_ANY_TAG,
			MPI_COMM_WORLD,
			MPI_STATUS_IGNORE);
			endtime = clock();
			time += (endtime - starttime);
			while (response != 2) {
				if (response == 1) {
					MPI_Recv(&firstIndex, 1, MPI_INT, status.MPI_SOURCE,
					MPI_ANY_TAG, MPI_COMM_WORLD,
					MPI_STATUS_IGNORE);
					MPI_Recv(wordFound, 30, MPI_CHAR, status.MPI_SOURCE,
					MPI_ANY_TAG, MPI_COMM_WORLD,
					MPI_STATUS_IGNORE);
					starttime = clock();
					std::string inputWordReceived(inputWords[firstIndex]);
					std::string wordFoundReceived(wordFound);
					memset(wordFound, 0, sizeof(wordFound));
					endtime = clock();
					time += (endtime - starttime);
					MPI_Recv(&editdistance, 1, MPI_INT, status.MPI_SOURCE,
					MPI_ANY_TAG, MPI_COMM_WORLD,
					MPI_STATUS_IGNORE);
					MPI_Recv(&numberText, 1, MPI_INT, status.MPI_SOURCE,
					MPI_ANY_TAG, MPI_COMM_WORLD,
					MPI_STATUS_IGNORE);
					starttime = clock();
					if (wordsFound[inputWordReceived][numberText].find(wordFoundReceived)
							== wordsFound[inputWordReceived][numberText].end()) {
						wordsFound[inputWordReceived][numberText][wordFoundReceived].push_back(
								editdistance);
						wordsFound[inputWordReceived][numberText][wordFoundReceived].push_back(1);
					} else
						wordsFound[inputWordReceived][numberText][wordFoundReceived][1]++;
					endtime = clock();
					time += (endtime - starttime);
				}
				starttime = clock();
				MPI_Recv(&response, 1, MPI_INT, status.MPI_SOURCE,
				MPI_ANY_TAG,
				MPI_COMM_WORLD,
				MPI_STATUS_IGNORE);
				endtime = clock();
				time += (endtime - starttime);
			}
		}
		if ((processes - 1) >= (iMax * (jMax + 1) + jMax)) {
			starttime = clock();
			finalIteration = 2;
			endtime = clock();
			time += (endtime - starttime);
			while (process < processes) {
				MPI_Send(&finalIteration, 1,
				MPI_INT, process, 0,
				MPI_COMM_WORLD);
				starttime = clock();
				process++;
				endtime = clock();
				time += (endtime - starttime);
			}
		}

		printf("Time: %f microseconds\n", time);

		for (int i = 0; i < inputWords.size(); i++) {
			if (wordsFound.find(inputWords[i]) == wordsFound.end()) {
				cout
						<< "Nessuna corrispondenza o somiglianza trovata nei testi per la parola '"
						<< inputWords[i] << "'." << endl;
			}
		}

		for (map<string, map<int, map<string, vector<int> > > >::iterator it =
				wordsFound.begin(); it != wordsFound.end(); ++it) {
			cout << "Parole trovate simili o uguali alla parola '" << it->first
					<< "':" << endl;
			for (map<int, map<string, vector<int> > >::iterator it2 =
					it->second.begin(); it2 != it->second.end(); ++it2) {
				cout << "Nel testo intitolato '" << nameText[it2->first] << "':"
						<< endl;
				for (map<string, vector<int> >::iterator it3 =
						it2->second.begin(); it3 != it2->second.end(); ++it3) {
					if (it3->second[1] == 1) {
						std::cout << "'" << it3->first
								<< "' con Edit Distance = " << it3->second[0]
								<< " ed è stata trovata " << it3->second[1]
								<< " volta." << endl;
					} else {
						std::cout << "'" << it3->first
								<< "' con Edit Distance = " << it3->second[0]
								<< " ed è stata trovata " << it3->second[1]
								<< " volte." << endl;
					}
				}
			}
		}
	} else {
		do {
			MPI_Recv(&finalIteration, 1, MPI_INT, 0, MPI_ANY_TAG,
			MPI_COMM_WORLD,
			MPI_STATUS_IGNORE);
			if (finalIteration != 2) {
				MPI_Recv(&firstIndex, 1, MPI_INT, 0, MPI_ANY_TAG,
				MPI_COMM_WORLD,
				MPI_STATUS_IGNORE);
				MPI_Recv(&secondIndex, 1, MPI_INT, 0, MPI_ANY_TAG,
				MPI_COMM_WORLD,
				MPI_STATUS_IGNORE);
				MPI_Recv(&thirdIndex, 1, MPI_INT, 0, MPI_ANY_TAG,
				MPI_COMM_WORLD,
				MPI_STATUS_IGNORE);
				MPI_Recv(&numberText, 1, MPI_INT, 0, MPI_ANY_TAG,
				MPI_COMM_WORLD,
				MPI_STATUS_IGNORE);
				std::string inputWordReceived(inputWords[firstIndex]);
				std::string lineWhereToFind(texts[secondIndex][thirdIndex]);

				for (int i = 0; i < lineWhereToFind.length(); i++) {
					if (static_cast<bool>(std::ispunct(lineWhereToFind[i]))) {
						std::replace(lineWhereToFind.begin(), lineWhereToFind.end(),
								static_cast<char>(lineWhereToFind[i]), ' ');
					}
				}

				for (int i = 0; i < lineWhereToFind.length(); i++) {
					if (static_cast<int>(lineWhereToFind[i]) == -62
							|| static_cast<int>(lineWhereToFind[i]) == -69) {
						int decimal = static_cast<int>(lineWhereToFind[i]);
						std::replace(lineWhereToFind.begin(), lineWhereToFind.end(),
								static_cast<char>(lineWhereToFind[i]), ' ');
						if (decimal == -62) {
							std::replace(lineWhereToFind.begin(), lineWhereToFind.end(),
									static_cast<char>(lineWhereToFind[i + 1]), ' ');
						}
					}
				}

				vector<string> words1;
				vector<string> words2;

				istringstream iss1(inputWordReceived);

				do {
					string word1;
					iss1 >> word1;
					if (word1.length() != 0) {
						words1.push_back(word1);
					}
				} while (iss1);

				istringstream iss2(lineWhereToFind);

				do {
					string word2;
					iss2 >> word2;
					if (word2.length() != 0) {
						words2.push_back(word2);
					}
				} while (iss2);

				for (int k = 0; k < words1.size(); k++) {
					for (int z = 0; z < words2.size(); z++) {
						editdistance = editDistance(words1[k], words2[z]);
						if (editdistance <= tolerance) {
							response = 1;
							MPI_Send(&response, 1, MPI_INT, 0, 0,
							MPI_COMM_WORLD);
							MPI_Send(&firstIndex, 1,
							MPI_INT, 0, 0, MPI_COMM_WORLD);
							MPI_Send(words2[z].c_str(), words2[z].length(),
							MPI_CHAR, 0, 0, MPI_COMM_WORLD);
							MPI_Send(&editdistance, 1,
							MPI_INT, 0, 0, MPI_COMM_WORLD);
							MPI_Send(&numberText, 1,
							MPI_INT, 0, 0, MPI_COMM_WORLD);
						} else {
							response = 0;
							MPI_Send(&response, 1, MPI_INT, 0, 0,
							MPI_COMM_WORLD);
						}
					}
				}
				response = 2;
				MPI_Send(&response, 1, MPI_INT, 0, 0, MPI_COMM_WORLD);
			}
		} while (finalIteration == 0);

	}

	MPI_Finalize(); // Shut down MPI

	return 0;
}
